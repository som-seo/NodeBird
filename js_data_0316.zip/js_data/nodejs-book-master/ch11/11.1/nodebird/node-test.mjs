import test from 'node:test';
import assert from 'assert';

test('1 + 1은 2입니다.', () => {
  assert.strictEqual(1 + 1, 2);
});
