'use strict';

const add=(a, b)=>{
    return a+b;
}
console.log(add(1, 4));