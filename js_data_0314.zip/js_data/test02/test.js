var  figlet  =  require ( 'figlet' ) ;

figlet ( 'Hello World!!' ,  function ( err ,  data )  { 
    if  ( err )  { 
        console . log ( '문제가 발생했습니다...' ) ; 
        console . dir ( err ) ; 
        return ; 
    } 
    console . log ( data ) 
} ) ;