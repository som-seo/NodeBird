/* B.js */

const A = require('./A');

console.log(A + ' in B.js');

