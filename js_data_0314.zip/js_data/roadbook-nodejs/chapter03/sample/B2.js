/* B2.js */

const A = require('./A2');
const B = 'variable B from B2.js';

console.log(A + ' in B2.js');

module.exports = B;
