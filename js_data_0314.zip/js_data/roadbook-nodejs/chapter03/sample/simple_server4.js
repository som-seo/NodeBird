const http = require('http');

http.createServer((req, res) => {
    if (req.url === '/') {
        res.write('Hello');
        res.end()
    }
})
    .listen(8084, () => {
        console.log('8084포트에서 서버 연결')
    });