/* A.js */

const A = 'variable A from A.js';

module.exports = A;

