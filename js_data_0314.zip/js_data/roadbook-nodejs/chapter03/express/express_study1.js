const express = require('express');
const app = express()

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.listen(8084, () =>
    console.log('8084포트에서 서버 실행중'));  