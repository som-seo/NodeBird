socket.on("from client", (data) => {
    console.log(data);
});