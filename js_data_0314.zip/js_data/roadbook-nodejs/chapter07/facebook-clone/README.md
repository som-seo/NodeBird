### Chapter7 facebook-clone 프로젝트 실행 방법
1. cd ./chapter07/facebook-clone
2. npm install
3. .env 파일 생성
5. https://cloudinary.com/ 회원가입 후 API키를 발급
6. cloudinary API key, secret, cloud_name을 .env에 작성(함께해봐요 7-27 참고)
7. mongodb 설정
8. $ npm start
