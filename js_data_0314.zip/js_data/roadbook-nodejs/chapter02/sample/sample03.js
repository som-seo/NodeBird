var puppy = "cute";
console.log(puppy); // cute
{
    var puppy = "so cute";
}
console.log(puppy); // so cute