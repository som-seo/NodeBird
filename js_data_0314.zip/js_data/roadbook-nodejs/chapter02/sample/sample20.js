console.log(0);

setTimeout(function () {
    console.log('Hello');
}, 0);

console.log(1);
