let dog;
dog = "happy";
console.log(dog); // happy
let dog = "happy"; // Identifier 'dog' has already been declared
