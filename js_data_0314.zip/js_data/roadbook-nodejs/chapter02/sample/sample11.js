const add = (a, b) => {
    return a + b;
}

console.log(add(1, 4)); // 5

// const add = (a, b) => a + b;