console.log(puppy);
var puppy = "cute";
console.log(puppy);