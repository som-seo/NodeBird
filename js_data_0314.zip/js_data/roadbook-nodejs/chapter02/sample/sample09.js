const animal = ['dog', 'cat'];

let [first, second] = animal;

console.log(first); // dog
console.log(second); // cat