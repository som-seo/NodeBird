let puppy = "cute";
{
    let puppy = "so cute";
}
console.log(puppy); // cute