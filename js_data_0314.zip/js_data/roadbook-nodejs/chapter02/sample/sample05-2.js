let dog;
console.log(dog); // undefined
dog = "so lovely";
console.log(dog); // so lovely