const express=require('express');
const {renderProfile, renderJoin, renderMain}=require('../controllers/page');

const router=express.Router();

router.use((req, res, next)=>{
    res.locals.user=null;
    res.locals.fllowerCount=0;
    res.locals.fllowingCount=0;
    res.locals.fllowingIdList=[];
    next();
});

router.get('/profile', renderProfile);
router.get('/join', renderJoin);
router.get('/', renderMain);

module.exports=router;